#include <asm-powerpc/perfctr.h>
